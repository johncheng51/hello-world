import dash
import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc

app = app = dash.Dash(external_stylesheets=[dbc.themes.BOOTSTRAP])

mainList=["John","Jack","Peter"]
list=mainList.copy()
list.append("All")
list.append("Clear")
options=[]
for i in list:
  options.append({'label': " "+i,'value': i })

app.layout = html.Div(
    children=dbc.DropdownMenu(
           children=
           [dcc.Checklist(
                id="checkList",
                options=options,
                value=[],
                labelStyle={'display': 'block'}
           )
           ],
         label="my Menu",
    ),
)

@app.callback(
    dash.dependencies.Output('checkList', 'value'),
    [dash.dependencies.Input('checkList', 'value')]
)
def checkList(name):
    if   "Clear" in name: return []
    elif "All"   in name: return mainList
    else : return name





if __name__ == '__main__':
    app.run_server()