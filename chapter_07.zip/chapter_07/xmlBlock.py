
from xmlHandler import XmlHandler
from xmlParser  import XmlParser
from xmlBody    import XmlBody
class XmlBlock(XmlHandler):

   NAME="name"
   parser:XmlParser
   def __init__(self, data):
      self.xmlData=data
      self.curTable = {}
      self.simTable = {}
      self.xmlTable = {}
      self.forList = False
      self.forXmlBody = False

   def process(self) :
    self.parser=XmlParser(self.xmlData,self)
    self.parser.parse();


   def startTag(self,cmd,att) :
         self.processBlock(cmd,att)
         return True

   def endTag(self,cmd,value):return True

   def processBlock(self,key,att) :
        block=self.parser.getContenda(key)
        if self.forList: self.simTable[key]=block
        elif self.forXmlBody:
           xmlBody=XmlBody(key,att,block)
           name=xmlBody.getMap().get(self.NAME)
           if not name: name=self.NAME
           newXml = self.xmlTable.get(name)
           if newXml: print(f"xmlTable already exist {name}")
           else:self.xmlTable[name]=xmlBody
        else:
             xmlBody=XmlBody(key,att,block)
             self.add(key,xmlBody)

   def add(self,key,xmlBody):
       map=self.curTable.get(key)
       if not map : map={}
       name=xmlBody.getMap().get(self.NAME)
       if not name: name=key+len(map)
       map[name]=xmlBody
       self.curTable[key]=map

  


