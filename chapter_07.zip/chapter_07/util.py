from readHash import ReadHash
from readProp import ReadProp
from xmlBlock import XmlBlock

QUIT='quit'
def personName(firstName,middleName = '',lastName = 'Cheng'):
    if middleName:
        full_name = firstName + ' ' +  middleName + ' ' + lastName
    else:
        full_name = firstName + ' ' + lastName
    return full_name.title()

def yesNo():
    value = input(f" Do again(Yes/No) ")
    return value.lower().startswith("y")

def readInput(comment):
    first = input(f"{comment} ")
    if first.find(QUIT)>=0 : first=QUIT
    return first

def progend() :
    print("Program End")

def removeItem(item,array) :
    while item in array:
        array.remove(item)

def readInt(comment):
    while True:
       a = input(comment)
       try:
          return int(a)
       except:
           print("Incorrect Format, please try agin")

def merge(ar,str) :
    return str.join(ar)

def getHash(text):
      return ReadHash(text).getTable()

def readProp(text):
      p= ReadProp(text)
      h=p.getMap()
      return h

def xmlBlockMap(text):
    xmlBlock=XmlBlock(text)
    xmlBlock.process()
    return xmlBlock.curTable


def xmlBlockSimple(text):
     xmlBlock=XmlBlock(text)
     xmlBlock.forList=True
     xmlBlock.process()
     return xmlBlock.simTable

def xmlBlockBody(text):
     xmlBlock=XmlBlock(text)
     xmlBlock.forXmlBody=True
     xmlBlock.process()
     return xmlBlock.xmlTable



