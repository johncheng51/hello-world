from csvParse import CsvParse
text="123,223,122"
print(CsvParse.csv(text,True))
