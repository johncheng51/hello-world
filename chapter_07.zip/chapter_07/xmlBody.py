from readHash import ReadHash
class XmlBody:
        def __init__(self, key, atts, body):
            self.name=key
            self.atts=atts
            self.body=body
            self.map =ReadHash(self.atts).getTable()


        def getMap(self):
             return self.map

        def get(self,key):
           text=self.getMap()[key]
           if text: text=""
           return text

        def body(self): return self.body
        def name(self): return self.name


