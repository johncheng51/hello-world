from abstractParse import AbstractParse
class CsvParse(AbstractParse):
   def __init__(self,data,putq):
     super().__init__(data)
     self.putq=putq
     self.list=[]
     self.parse()


   def qq(self,text):
      if not self.putq: return text
      return self.CQ+self.qqq(text)+self.CQ

   def parse(self) :
        key=""
        while True:
          c=self.getChar0()
          if   c=='$' or c==' ': continue
          elif c == self.CEND:
              self.doKey(key)
              break
          elif   c=='\"':key=self.qq(self.skipToChar(c))
          elif   c=='\'':key=self.qq(self.doQ())
          elif   c==',' :self.doKey(key)
          else: key+=c

   def doKey(self,text) :
       if text: self.list.append(text)

   def  qqq(self,text) :
        re=""
        for c in text:
         if c=='\'': re+=c;re+=c
         else: re+=c
        return re


   @staticmethod
   def csv(text,putq):
      cp=CsvParse(text,putq)
      return cp.list



