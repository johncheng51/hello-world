from abstractParse import AbstractParse
from xmlHandler import XmlHandler

class XmlParser(AbstractParse):
  def __init__(self,data,xmlr:XmlHandler):
        super().__init__(data + " ")
        self.xmlr:XmlHandler = xmlr



  def  parse(self):
        c="";cmd   = "";ecmd  = "";
        att   = "";isEndTag=False;
        value = "";
        sb = "";
        inBraket=False;
        while True:
         c = self.getChar();
         if c=='<':
            inBraket = True
            value = sb
            sb = ""
            cmd = self.getWord()
            att = self.getAtts()
            isEndTag = False
            if cmd : isEndTag =  not self.xmlr.startTag(cmd, att);
            if isEndTag: inBraket = False
         elif c== '/':
                if not inBraket:  sb+=c
                ecmd = self.getWord()
                if ecmd: cmd = ecmd;
                if not self.xmlr.endTag(cmd, value):  break
         elif c== '>':inBraket = False
         elif c== '\n':sb+=c;
         elif c==self.CEND: break
         else : sb += c;
            

