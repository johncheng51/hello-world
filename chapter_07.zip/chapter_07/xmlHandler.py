
class XmlHandler :
     def  startTag(cmd, att):pass
     def  endTag(cmd, value):pass

