from abstractParse import AbstractParse
class ReadHash(AbstractParse):
    def __init__(self, data):
         super().__init__(data+" ")
         self.parse();

    def parse(self):
     while True:
       c=self.getChar()
       print(c)
       if   c== self.CEND:return
       elif self.isSpace(c):
           self.putValue(False)
       elif c== '=':self._haveKey = True
       elif c== self.CQ:self.putValue(true);
       elif not self._haveKey: self.addKey(c);
       else : self.addValue(c);


     def read(text):
      return ReadHash(text).getTable()
                    
                     

 


