class AbstractParse:
    CEND=0;CQ = '\'';CQQ='"';NT='\n';RT='\r';TT='\t';
    _longStr="";_size=0
    _currentMap={}
    _currentPos=0
    _key = ""
    _value = ""
    _haveKey = False
    _isSpace = False
    _isSpaceBefore = False
    _lastChar=''
    _currentChar=''

    def __init__(self, data):
        if not data: data=""
        self._longStr = " "+data
        self._size = len(self._longStr)-1
        self._currentMap={}

    def getTable(self):
      return self._currentMap

    def parse(self): pass
    def addKey(self, c):     self._key += c
    def addValue(self, c):   self._value += c
    def getTextPos(self, c): return self.currentPos
    def moveTextPos(self,n): self._currentPos = n
    def noKey(self): return not not self._key
    def isSpaceBefore(self): return self._isSpaceBefore

    def setLast(self):
        self._lastChar =self._currentChar
        self._isSpaceBefore =self._isSpace

    def getValue(self):
         result = self.value
         self.value = ""
         return result

    def getKey(self):
       result =self._key
       self.key =""
       return result

    def getValue(self):
        result = self._value
        value = ""
        return result

    """ """
    def doQ(self):
        result=self.CQ
        while True:
          c = self.getChar0()
          if c==self.CEND: break
          elif c==self.CQ:
              result+=self.CQ
              ne = self.next()
              if ne==self.CQ : result+=self.getChar0()
              else: break
          else:result+=c
        return result

    def next(self):
     if self.isOver() : return self.CEND;
     return self._longStr[self._currentPos]

    def isOver(self):
        return self._currentPos == self._size

    def isQQ(self,c):
       return  c == self.CQQ or c == self.CQ

    def getAtts(self):
      sb = ""
      while True:
       c = self.getChar()
       if c==self.CEND: break
       if c == self.CQQ or c==self.CQ :
         sb += self.getValue()
       if c == '/' or c == '>':
           self._currentPos=self._currentPos -1
           break
       sb += c
      return sb

    def  getChar0(self):
     c=self.CEND
     if self.isOver(): c=self.CEND
     else:
         self._currentPos=self._currentPos+1
         c=self._longStr[self._currentPos]
     return c

    def isSpace(self,c):
       flag=  (c == self.NT) or \
               (c == self.RT) or \
               (c == self.TT) or \
               (c == ' ')
       return flag

    def isRTN(self,c):
       flag=   (c == self.NT) or \
               (c == self.RT)
       return flag

    def  getChar(self):
      c=  self.getChar0()
      self._currentChar = c
      self._isSpace = False
      if self.isSpace(c):
          self._currentChar= ' '
          self._isSpace = True
      if self.isQQ(c): self._value=c+self.skipToChar(c)
      return self._currentChar



    def skipToChar(self,patt):
      result = ""
      while True:
        c = self.getChar0()
        if c == self.CEND or c == patt : break
        result += c;
      return result;

    def rest(self):
        return self._longStr[self._currentPos:]

    def getWord(self):
      result = ""
      while True:
        c = self.getChar0()
        if c==' ':break
        if c=='/' or c=='>':
            self._currentPos-=1
            break
        else : result += c
      return result

    def putValue(self,isQ):
        if len(self._key)==0 : return;
        if (not isQ) and len(self._value) == 0: return;
        self._currentMap[self._key]= self._value
        self._key = ""
        self._value = ""
        self._haveKey = False


    def getContend(self,pattern):
         n = self._currentPos+2
         self.skipTo(pattern)
         result = self._longStr[n:self._currentPos - 1]
         return result

    def getContenda(self,pattern):
        pattern = "</" + pattern + ">"
        result = self.getContend(pattern)
        return result

    def skipTo(self,pattern):
        s = self._longStr[self._currentPos:]
        n = s.find(pattern)
        self._currentPos += n + 1











