from abstractParse import AbstractParse
from readHash import ReadHash

class ReadProp(AbstractParse):

   def __init__(self, data):
     super().__init__(data + " ")
     self.parse()

   
   def parse(self):
     lincC=False
     while True:
       c=self.getChar0()
       if c==self.CEND:
           self.putValue(False);return
       elif self.isRTN(c):
            if (lineC): self.addValue(' ')
            else:self.putValue(False)
       elif  c== '\\':
             lineC=self.isSkip()
             if not lineC: self.addValue(c)
       elif c=='=':
           if self._haveKey: self.addValue(c);
           else:   self._haveKey = True
       else:
           if self._haveKey: self.addValue(c);
           else: self.addKey(c)
           lineC = False


   
   def isSkip(self):
      for x in range(5):
          print(x)
      return True


    

   def getMap(self):
        result = {}
        temp = self.getTable()
        for  key in  temp.keys():
           val = temp[key]
           ht = ReadHash(val).getTable()
           result[key]=ht
        return result

   


  
    


